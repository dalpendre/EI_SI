﻿using EI.SI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace MITM
{
    class MITM
    {
        static void Main(string[] args)
        {
            #region VARIABLES

            //Client
            ProtocolSI protocol = null;
            TcpListener clientListener = null;
            TcpClient client = null;
            NetworkStream clientStream = null;
            IPEndPoint clientEndpoint = null;

            #endregion
            try
            {
                #region SOCKET SET UP

                protocol = new ProtocolSI();
                clientEndpoint = new IPEndPoint(IPAddress.Any, 9998);
                clientListener = new TcpListener(clientEndpoint);
                clientListener.Start();
                client = clientListener.AcceptTcpClient();    //Chamada bloqueante
                clientStream = client.GetStream();

                #endregion

                #region COMMUNICATION
                do
                {
                    Console.WriteLine("Waiting for Client");
                    clientStream.Read(protocol.Buffer, 0, protocol.Buffer.Length);
                    switch (protocol.GetCmdType())
                    {
                        case ProtocolSICmdType.NORMAL:
                            Console.WriteLine("Received Integer: {0}", protocol.GetIntFromData());
                            break;
                        case ProtocolSICmdType.DATA:
                            Console.WriteLine("Received String: {0}", protocol.GetStringFromData());
                            break;
                        case ProtocolSICmdType.EOT:
                            Console.WriteLine("Received EOT");
                            break;
                    }
                    Console.WriteLine("Sending ACK");
                    byte[] ack = protocol.Make(ProtocolSICmdType.ACK);
                    clientStream.Write(ack, 0, ack.Length);
                    Console.WriteLine();

                } while (protocol.GetCmdType() != ProtocolSICmdType.EOT);
                #endregion
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                if (clientStream != null) clientStream.Close();
                if (client != null) client.Close();
                if (clientListener != null) clientListener.Stop();
            }
            Console.ReadLine();
        }
    }
}
